from Connect import app
from flask import render_template, request, redirect, url_for, flash, get_flashed_messages
from Connect.models import Users, Post
from Connect.forms import RegisterForm
from Connect import db

@app.route('/') 
@app.route('/home')
def home_page():
    return render_template("home.html")

@app.route('/job_offers')
def job_offers():
    posts = Post.query.all()
    return render_template("job_offers.html", posts=posts)

@app.route('/about_us')
def about_us():
    return render_template("about_us.html")

@app.route('/contact_us')
def contact_us():
    return render_template("contact_us.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    form = RegisterForm()
    data_check=""
    if request.method == "POST":
        data_check = request.form.get("checkbox")
        if data_check != None:
            data_check = True
        else:
            data_check= False
    

    if form.validate_on_submit():
        user = Users(email=form.email_address.data,
                    name=form.name.data,
                    employer =data_check,
                    password=form.password1.data)

        db.session.add(user)
        db.session.commit()
        return redirect(url_for("job_offers"))

    if form.password1.data != form.password2.data:
            flash("Password and Confirm Password are not same", category="danger")

    elif form.errors != {}:
        for err_msg in form.errors.values():
            flash(err_msg[0], category="danger")
            break
    print(form.errors)
    return render_template("register.html", form=form)
    